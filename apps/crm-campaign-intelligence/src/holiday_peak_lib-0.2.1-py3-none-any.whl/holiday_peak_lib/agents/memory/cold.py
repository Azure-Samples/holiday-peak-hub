"""Cold memory layer using Azure Blob Storage."""

import asyncio

from azure.core.pipeline.transport import AioHttpTransport
from azure.identity import DefaultAzureCredential
from azure.storage.blob.aio import BlobServiceClient
from holiday_peak_lib.utils.logging import configure_logging, log_async_operation

logger = configure_logging()


class ColdMemory:
    """Blob-backed cold memory for long-term state."""

    def __init__(
        self,
        account_url: str,
        container_name: str,
        *,
        connection_pool_size: int | None = None,
        connection_timeout: float | None = None,
        read_timeout: float | None = None,
    ) -> None:
        self.account_url = account_url
        self.container_name = container_name
        self.connection_pool_size = connection_pool_size
        self.connection_timeout = connection_timeout
        self.read_timeout = read_timeout
        self.client: BlobServiceClient | None = None
        self._connect_lock = asyncio.Lock()

    async def connect(self) -> None:
        if self.client is not None:
            return

        async with self._connect_lock:
            if self.client is not None:
                return

            async def _connect():
                credential = DefaultAzureCredential()
                transport = None
                if any(
                    value is not None
                    for value in (
                        self.connection_pool_size,
                        self.connection_timeout,
                        self.read_timeout,
                    )
                ):
                    transport = AioHttpTransport(
                        connection_timeout=self.connection_timeout,
                        read_timeout=self.read_timeout,
                        connection_pool_size=self.connection_pool_size,
                    )
                self.client = BlobServiceClient(
                    self.account_url,
                    credential=credential,
                    transport=transport,
                )

            await log_async_operation(
                logger,
                name="cold_memory.connect",
                intent=self.account_url,
                func=_connect,
                metadata={"account_url": self.account_url},
            )

    async def upload_text(self, blob_name: str, data: str) -> None:
        if not self.client:
            await self.connect()
        container = self.client.get_container_client(self.container_name)
        await log_async_operation(
            logger,
            name="cold_memory.upload_text",
            intent=blob_name,
            func=lambda: container.upload_blob(name=blob_name, data=data, overwrite=True),
            metadata={"container": self.container_name},
        )

    async def download_text(self, blob_name: str) -> str:
        if not self.client:
            await self.connect()
        container = self.client.get_container_client(self.container_name)

        async def _download():
            stream = await container.download_blob(blob_name)
            return await stream.readall()

        return await log_async_operation(
            logger,
            name="cold_memory.download_text",
            intent=blob_name,
            func=_download,
            metadata={"container": self.container_name},
        )
